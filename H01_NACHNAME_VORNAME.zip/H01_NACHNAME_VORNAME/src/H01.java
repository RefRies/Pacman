
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import fopbot.World;

public class H01 {

	public static Timer keyTimer = new Timer();
	public static Timer ghostTimer = new Timer();
	public static Timer gameTimer = new Timer();
	public static int totalCoins = 0;

	private static HashMap<Integer, Boolean> keysPressed;

	public static void main(String[] args) {
		keysPressed = new HashMap<Integer, Boolean>();
		for (int k = KeyEvent.VK_LEFT; k <= KeyEvent.VK_DOWN; k++) {
			keysPressed.put(k, false);
		}

		int width = 10;
		int height = 10;

		World.setSize(width, height);
		World.setVisible(true);
		World.setDelay(0);
		divide(0, 0, width, height);

		for (int i = 0; i < width; i++) {
			for (int j = 0; j < height; j++) {
				if (i == 0 && j == 0) {
					continue;
				}
				Random rnd = new Random();
				if (rnd.nextInt(2) == 1) {
					World.putCoins(i, j, 1);
					totalCoins++;
				}
			}
		}

		World.getGlobalWorld().getGuiPanel().addKeyListener(new KeyListener() {

			@Override
			public void keyTyped(KeyEvent e) {
			}

			@Override
			public void keyPressed(KeyEvent e) {
				for (int k = KeyEvent.VK_LEFT; k <= KeyEvent.VK_DOWN; k++) {
					if (e.getKeyCode() == k) {
						keysPressed.put(k, true);
					}
				}
			}

			@Override
			public void keyReleased(KeyEvent e) {
				for (int k = KeyEvent.VK_LEFT; k <= KeyEvent.VK_DOWN; k++) {
					if (e.getKeyCode() == k) {
						keysPressed.put(k, false);
					}
				}
			}
		});

		World.getGlobalWorld().getGuiPanel().setFocusable(true);
		World.getGlobalWorld().getGuiPanel().requestFocusInWindow();
		try {
			World.getGlobalWorld().setAndLoadRobotImages(Pacman.class, new FileInputStream(new File("res/pacman.png")),
					new FileInputStream(new File("res/pacman.png")), 270, 270);

			World.getGlobalWorld().setAndLoadRobotImages(BlueGhost.class,
					new FileInputStream(new File("res/ghost_blue.png")),
					new FileInputStream(new File("res/ghost_blue.png")), 0, 0);

			World.getGlobalWorld().setAndLoadRobotImages(OrangeGhost.class,
					new FileInputStream(new File("res/ghost_orange.png")),
					new FileInputStream(new File("res/ghost_orange.png")), 0, 0);

		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}
		Pacman pacman = new Pacman(6, 6);
		BlueGhost blue = new BlueGhost(8, 2);
		OrangeGhost orange = new OrangeGhost(4, 5);

		keyTimer.scheduleAtFixedRate(new TimerTask() {
			@Override
			public void run() {
				int keyPressed = -1;
				for (int k = KeyEvent.VK_LEFT; k <= KeyEvent.VK_DOWN; k++) {
					if (keysPressed.get(k)) {
						// key is pressed
						if (keyPressed == -1) {
							// first key found
							keyPressed = k;
						} else {
							// multiple keys found
							keyPressed = -1;
							break;
						}
					}
				}

				if (keyPressed == -1) {
					pacman.handleKeyInput(keyPressed);
				} else {
					pacman.handleKeyInput(keyPressed - KeyEvent.VK_LEFT);
					// KeyEvent.VK_LEFT = 0
					// KeyEvent.VK_UP = 1
					// KeyEvent.VK_RIGHT = 2
					// KeyEvent.VK_DOWN = 3
				}
			}
		}, 0, 100);

		ghostTimer.scheduleAtFixedRate(new TimerTask() {
			@Override
			public void run() {
				orange.doMove();
				blue.doMove();
			}
		}, 0, 300);

		gameTimer.scheduleAtFixedRate(new TimerTask() {
			@Override
			public void run() {
				boolean gameDone = false;
				if (pacman.getX() == orange.getX() && pacman.getY() == orange.getY()) {
					gameDone = true;
				}

				if (pacman.getX() == blue.getX() && pacman.getY() == blue.getY()) {
					gameDone = true;
				}

				if (gameDone || pacman.getNumberOfCoins() == totalCoins) {
					keyTimer.cancel();
					ghostTimer.cancel();
					gameTimer.cancel();
				}

			}
		}, 0, 10);

	}

	public static void divide(int x, int y, int width, int height) {
		boolean horizontal;
		if (width < height) {
			horizontal = true;
		} else {
			if (height < width) {
				horizontal = false;
			} else {
				int number = Util.getRandomInteger(0, 1);
				if (number == 0) {
					horizontal = true;
				} else {
					horizontal = false;
				}
			}
		}
		if (width < 2 || height < 2) {
			return;
		}

		if (horizontal == false) {
			int wallX = Util.getRandomInteger(x, x + width - 2);
			int passageY = Util.getRandomInteger(y, y + height - 1);
			int passageY2 = Util.getRandomInteger(y, y + height - 1);

			for (int h = y; h < y + height; h++) {
				if (width > 2 && h == passageY2) {
					continue;
				}
				if (h == passageY) {
					continue;
				}
				World.placeVerticalWall(wallX, h);
			}

			int f1X = x;
			int f1Y = y;
			int f1Width = wallX - x + 1;
			int f1Height = height;
			divide(f1X, f1Y, f1Width, f1Height);

			int f2X = wallX + 1;
			int f2Y = y;
			int f2Width = width - f1Width;
			int f2Height = height;
			divide(f2X, f2Y, f2Width, f2Height);
		} else {
			int wallY = Util.getRandomInteger(y, y + height - 2);
			int passageX = Util.getRandomInteger(x, x + width - 1);
			int passageX2 = Util.getRandomInteger(x, x + width - 1);

			for (int w = x; w < x + width; w++) {
				if (height > 2 && w == passageX2) {
					continue;
				}

				if (w == passageX) {
					continue;
				}
				World.placeHorizontalWall(w, wallY);
			}

			int f1X = x;
			int f1Y = y;
			int f1Width = width;
			int f1Height = wallY - y + 1;
			divide(f1X, f1Y, f1Width, f1Height);

			int f2X = x;
			int f2Y = wallY + 1;
			int f2Width = width;
			int f2Height = height - f1Height;
			divide(f2X, f2Y, f2Width, f2Height);

		}

	}

}

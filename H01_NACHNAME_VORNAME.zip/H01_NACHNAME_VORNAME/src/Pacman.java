
import fopbot.Direction;
import fopbot.Robot;
import static fopbot.Direction.*;

public class Pacman extends Robot {

	public Pacman(int x, int y) {
		super(x, y);
	}


	/**
	 * Used by the gui to handle key inputs
	 * 
	 * @param k (key pressed)
	 */
	public void handleKeyInput(int k) {
		// TODO: H1
	}

}

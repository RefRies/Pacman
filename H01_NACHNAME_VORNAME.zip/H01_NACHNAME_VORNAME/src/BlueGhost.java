
import fopbot.Direction;
import fopbot.Robot;
import static fopbot.Direction.*;

public class BlueGhost extends Robot {

	public BlueGhost(int x, int y) {
		super(x, y);
	}


	public void doMove() {
		// TODO: H2.1
	}

}

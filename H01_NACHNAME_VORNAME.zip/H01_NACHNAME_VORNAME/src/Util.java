
import java.util.Random;

public class Util {

	private static Random rnd = new Random();

	/**
	 * @param min
	 * @param max
	 * @return a random integer between min and max (both inclusive)
	 */
	public static int getRandomInteger(int min, int max) {
		return min + rnd.nextInt(max - min + 1);
	}

}

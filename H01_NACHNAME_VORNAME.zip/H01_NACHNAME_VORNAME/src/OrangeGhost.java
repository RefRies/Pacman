
import fopbot.Robot;

public class OrangeGhost extends Robot {

	public OrangeGhost(int x, int y) {
		super(x, y);
	}


	public void doMove() {
		// TODO: H2.2
	}

}

package fopbot;

public enum Direction {
	UP, DOWN, LEFT, RIGHT;
}

package fopbot;

public class Block extends FieldEntity {

	/**
	 * Creates a new block at field (x,y)
	 * 
	 * @param x
	 * @param y
	 */
	public Block(int x, int y) {
		super(x, y);
	}

}
